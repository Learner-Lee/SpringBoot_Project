package com.example.ssss;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SsssApplicationTests {

    @Test
    void contextLoads() {
    }

}
