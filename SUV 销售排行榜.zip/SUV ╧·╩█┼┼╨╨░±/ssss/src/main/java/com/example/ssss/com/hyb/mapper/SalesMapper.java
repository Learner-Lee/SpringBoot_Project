package com.example.ssss.com.hyb.mapper;

import com.example.ssss.com.hyb.pojo.Sales;
import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Select;

import java.util.List;

@Mapper
public interface SalesMapper {
    @Select("select * from tb_salesinfo")
    List<Sales> getAllUser();

    @Delete("delete from tb_salesinfo where id = #{id}")
    void deleteUser(Integer id);
    // 查询所有
    @Select("SELECT * FROM `tb_salesinfo` WHERE model LIKE '%${keyword}%'")
    List<Sales> getUser(String keyword);
}
