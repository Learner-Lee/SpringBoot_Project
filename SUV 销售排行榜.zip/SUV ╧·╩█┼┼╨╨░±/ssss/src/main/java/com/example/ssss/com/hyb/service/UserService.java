package com.example.ssss.com.hyb.service;

import com.example.ssss.com.hyb.pojo.Sales;

import java.util.List;

public interface UserService {

    List<Sales> getAllUser();

    void deleteUser(Integer id);

    List<Sales> getUser(String keyword);
}
