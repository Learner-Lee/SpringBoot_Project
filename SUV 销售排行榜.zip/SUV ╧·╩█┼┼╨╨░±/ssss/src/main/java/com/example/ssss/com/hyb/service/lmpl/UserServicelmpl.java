package com.example.ssss.com.hyb.service.lmpl;

import com.example.ssss.com.hyb.mapper.SalesMapper;
import com.example.ssss.com.hyb.pojo.Sales;
import com.example.ssss.com.hyb.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServicelmpl implements UserService {
    @Autowired
    private SalesMapper salesMapper;

    @Override
    public List<Sales> getAllUser() {
        return this.salesMapper.getAllUser();
    }

    @Override
    public void deleteUser(Integer id) {
        System.out.println("删除了id为"+id+"的用户");
        this.salesMapper.deleteUser(id);
    }

    @Override
    public List<Sales> getUser(String keyword) {
        return this.salesMapper.getUser(keyword);
    }
}
