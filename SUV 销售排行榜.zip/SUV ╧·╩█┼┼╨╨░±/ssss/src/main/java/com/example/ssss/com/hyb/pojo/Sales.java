package com.example.ssss.com.hyb.pojo;

import lombok.Data;

@Data
public class Sales {
    private int id;
    private String brand;
    private String model;
    private int sales;
}
