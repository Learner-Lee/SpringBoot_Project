package com.example.ssss.com.hyb.controller;

import com.example.ssss.com.hyb.pojo.Sales;
import com.example.ssss.com.hyb.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/user")
public class UserConterller {

    @Autowired
    private UserService userService;

    @RequestMapping("/userList")
    public List<Sales> getAllUsers(){
        return this.userService.getAllUser();
    }
    @RequestMapping("/delete/{id}")
    public void deleteUser(@PathVariable Integer id){
        this.userService.deleteUser(id);
    }
    @RequestMapping("/userListfew/{keyword}")
    public List<Sales> getUsers(@PathVariable String keyword){
        return this.userService.getUser(keyword);
    }
}
