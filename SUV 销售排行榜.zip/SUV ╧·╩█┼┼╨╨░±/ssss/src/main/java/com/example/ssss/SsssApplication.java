package com.example.ssss;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SsssApplication {

    public static void main(String[] args) {
        SpringApplication.run(SsssApplication.class, args);
    }

}
