/*
 Navicat Premium Data Transfer

 Source Server         : MySQL56
 Source Server Type    : MySQL
 Source Server Version : 50618
 Source Host           : localhost:3306
 Source Schema         : ssss-db

 Target Server Type    : MySQL
 Target Server Version : 50618
 File Encoding         : 65001

 Date: 03/12/2023 11:29:35
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for tb_salesinfo
-- ----------------------------
DROP TABLE IF EXISTS `tb_salesinfo`;
CREATE TABLE `tb_salesinfo`  (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `brand` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `model` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL,
  `sales` int(11) NOT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 6 CHARACTER SET = utf8 COLLATE = utf8_general_ci ROW_FORMAT = Compact;

-- ----------------------------
-- Records of tb_salesinfo
-- ----------------------------
INSERT INTO `tb_salesinfo` VALUES (1, '长城', '哈弗h6', 52734);
INSERT INTO `tb_salesinfo` VALUES (2, '长安', 'cs75 plus', 30963);
INSERT INTO `tb_salesinfo` VALUES (3, '本田', 'CR-V', 27580);
INSERT INTO `tb_salesinfo` VALUES (4, '吉利', '博越', 25062);
INSERT INTO `tb_salesinfo` VALUES (5, '日产', '逍客', 21652);

SET FOREIGN_KEY_CHECKS = 1;
