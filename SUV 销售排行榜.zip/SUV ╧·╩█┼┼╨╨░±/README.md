### 本项目由`SpringBoot`编写

练手项目，数据不一定真实



#### `ssss`为项目文件，`tb_salesinfo.sql`为所需数据库



#### `SsssApplication`为启动文件



#### `application.yml`为配置文件



#### `static`文件中包含前端代码



**实现效果为：**

网址为：http://127.0.0.1:8080/user.html

![image-20231203114043546](assets/image-20231203114043546.png)